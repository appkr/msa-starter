/**
 * Service layer beans.
 */
package dev.appkr.uaa.service;
