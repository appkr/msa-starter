/**
 * Spring Data JPA repositories.
 */
package dev.appkr.uaa.repository;
