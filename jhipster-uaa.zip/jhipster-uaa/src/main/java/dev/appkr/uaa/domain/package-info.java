/**
 * JPA domain objects.
 */
package dev.appkr.uaa.domain;
