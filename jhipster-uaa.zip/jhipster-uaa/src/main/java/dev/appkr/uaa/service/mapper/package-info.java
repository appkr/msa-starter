/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package dev.appkr.uaa.service.mapper;
