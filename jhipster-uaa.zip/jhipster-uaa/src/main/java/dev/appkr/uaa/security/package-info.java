/**
 * Spring Security configuration.
 */
package dev.appkr.uaa.security;
