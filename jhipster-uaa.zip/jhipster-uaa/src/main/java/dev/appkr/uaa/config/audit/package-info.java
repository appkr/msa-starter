/**
 * Audit specific code.
 */
package dev.appkr.uaa.config.audit;
