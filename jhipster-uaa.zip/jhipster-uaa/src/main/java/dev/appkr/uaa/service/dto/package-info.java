/**
 * Data Transfer Objects.
 */
package dev.appkr.uaa.service.dto;
