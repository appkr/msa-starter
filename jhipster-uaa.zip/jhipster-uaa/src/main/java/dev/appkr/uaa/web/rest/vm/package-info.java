/**
 * View Models used by Spring MVC REST controllers.
 */
package dev.appkr.uaa.web.rest.vm;
